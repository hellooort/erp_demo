import React, { useState, useMemo } from 'react';
import {
  LayoutDashboard, FileText, ShoppingCart, ArrowDownRight, TrendingUp,
  Search, User, Plus, Download, Package, CheckCircle2, Clock, Box, Printer, X
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

type ViewType = 'dashboard' | 'itemMaster' | 'order' | 'po' | 'receiving' | 'performance';

type Item = { code: string; name: string; spec: string; material: string };
type Order = { id: string; date: string; client: string; itemCode: string; qty: number; price: number; status: string };
type PO = { id: string; date: string; supplier: string; itemCode: string; qty: number; price: number; status: string };

const initialItems: Item[] = [
  { code: 'ITM-001', name: '산업용 모터 A형', spec: '220V 50Hz', material: '철/구리' },
  { code: 'ITM-002', name: '제어용 PCB 보드', spec: 'Rev 2.1', material: 'FR4' },
  { code: 'ITM-003', name: '알루미늄 프레임', spec: '1000x500x50', material: 'AL6061' },
];

const initialOrders: Order[] = [
  { id: 'ORD-001', date: '2024-03-20', client: '(주)한국테크', itemCode: 'ITM-001', qty: 10, price: 1500000, status: '수주확정' },
  { id: 'ORD-002', date: '2024-03-21', client: '글로벌솔루션', itemCode: 'ITM-002', qty: 50, price: 170000, status: '견적대기' },
];

const initialPOs: PO[] = [
  { id: 'PO-001', date: '2024-03-21', supplier: '에이원부품', itemCode: 'ITM-001', qty: 10, price: 1200000, status: '입고완료' },
  { id: 'PO-002', date: '2024-03-22', supplier: '비전전자', itemCode: 'ITM-002', qty: 50, price: 90000, status: '대기중' },
];

const mockPerformance = {
  monthlySales: [
    { month: '1월', sales: 140, target: 160 },
    { month: '2월', sales: 190, target: 170 },
    { month: '3월', sales: 220, target: 190 },
  ]
};

const formatCurrency = (amount: number) => new Intl.NumberFormat('ko-KR', { style: 'currency', currency: 'KRW' }).format(amount);

const StatusBadge = ({ status }: { status: string }) => {
  let colorClass = 'bg-slate-100 text-slate-700';
  let Icon = Clock;
  if (status === '수주확정' || status === '입고완료') { colorClass = 'bg-emerald-100 text-emerald-700'; Icon = CheckCircle2; }
  else if (status === '견적대기' || status === '대기중') { colorClass = 'bg-amber-100 text-amber-700'; Icon = Clock; }
  return (
    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium ${colorClass}`}>
      <Icon className="w-3.5 h-3.5" />{status}
    </span>
  );
};

const Modal = ({ title, onClose, children }: { title: string, onClose: () => void, children: React.ReactNode }) => (
  <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
    <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="bg-white rounded-2xl shadow-xl w-full max-w-md overflow-hidden">
      <div className="flex justify-between items-center p-6 border-b border-slate-100">
        <h3 className="text-lg font-bold text-slate-900">{title}</h3>
        <button onClick={onClose} className="text-slate-400 hover:text-slate-600"><X className="w-5 h-5" /></button>
      </div>
      <div className="p-6">
        {children}
      </div>
    </motion.div>
  </div>
);

// --- Views ---
const DashboardView = ({ items, orders, pos }: { key?: string, items: Item[], orders: Order[], pos: PO[] }) => {
  const totalSales = orders.filter(o => o.status === '수주확정').reduce((sum, o) => sum + (o.qty * o.price), 0);
  const pendingPOs = pos.filter(p => p.status === '대기중').length;
  const todayReceives = pos.filter(p => p.status === '입고완료').length; // Simplified for demo

  return (
    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { title: '등록된 품목', value: `${items.length}건`, icon: Box, color: 'text-indigo-600', bg: 'bg-indigo-100' },
          { title: '총 수주액', value: formatCurrency(totalSales), icon: FileText, color: 'text-emerald-600', bg: 'bg-emerald-100' },
          { title: '대기중 발주', value: `${pendingPOs}건`, icon: ShoppingCart, color: 'text-amber-600', bg: 'bg-amber-100' },
          { title: '입고 완료', value: `${todayReceives}건`, icon: ArrowDownRight, color: 'text-blue-600', bg: 'bg-blue-100' },
        ].map((stat, i) => (
          <div key={i} className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 flex items-center gap-4">
            <div className={`p-4 rounded-xl ${stat.bg}`}><stat.icon className={`w-6 h-6 ${stat.color}`} /></div>
            <div><p className="text-sm font-medium text-slate-500">{stat.title}</p><p className="text-2xl font-bold text-slate-900 mt-1">{stat.value}</p></div>
          </div>
        ))}
      </div>
    </motion.div>
  );
};

const ItemMasterView = ({ items, onAddItem }: { key?: string, items: Item[], onAddItem: (item: Item) => void }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [formData, setFormData] = useState({ code: '', name: '', spec: '', material: '' });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newItem = {
      ...formData,
      code: formData.code || `ITM-${String(items.length + 1).padStart(3, '0')}`
    };
    onAddItem(newItem);
    setIsModalOpen(false);
    setFormData({ code: '', name: '', spec: '', material: '' });
  };

  return (
    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-slate-900">품목 마스터</h2>
        <button onClick={() => setIsModalOpen(true)} className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 text-sm font-medium shadow-sm">
          <Plus className="w-4 h-4" /> 신규 품목 등록
        </button>
      </div>
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <table className="w-full text-sm text-left">
          <thead className="bg-slate-50 text-slate-500 border-b border-slate-200">
            <tr><th className="px-6 py-4">품목코드</th><th className="px-6 py-4">품명</th><th className="px-6 py-4">규격</th><th className="px-6 py-4">재질</th></tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {items.map(item => (
              <tr key={item.code} className="hover:bg-slate-50">
                <td className="px-6 py-4 font-medium text-indigo-600">{item.code}</td>
                <td className="px-6 py-4 font-medium text-slate-900">{item.name}</td>
                <td className="px-6 py-4 text-slate-600">{item.spec}</td>
                <td className="px-6 py-4 text-slate-600">{item.material}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {isModalOpen && (
        <Modal title="신규 품목 등록" onClose={() => setIsModalOpen(false)}>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">품목코드</label>
              <input type="text" placeholder="미입력 시 자동 생성" className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500" value={formData.code} onChange={e => setFormData({...formData, code: e.target.value})} />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">품명 *</label>
              <input type="text" required className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">규격</label>
              <input type="text" className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500" value={formData.spec} onChange={e => setFormData({...formData, spec: e.target.value})} />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">재질</label>
              <input type="text" className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500" value={formData.material} onChange={e => setFormData({...formData, material: e.target.value})} />
            </div>
            <button type="submit" className="w-full py-2.5 bg-indigo-600 text-white rounded-lg font-medium hover:bg-indigo-700 mt-6">등록하기</button>
          </form>
        </Modal>
      )}
    </motion.div>
  );
};

const OrderView = ({ orders, items, onAddOrder }: { key?: string, orders: Order[], items: Item[], onAddOrder: (order: Order) => void }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [formData, setFormData] = useState({ client: '', itemCode: '', qty: 1, price: 0, status: '견적대기' });
  const getItemName = (code: string) => items.find(i => i.code === code)?.name || code;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.itemCode) return alert('품목을 선택해주세요.');
    const newOrder = {
      ...formData,
      id: `ORD-${String(orders.length + 1).padStart(3, '0')}`,
      date: new Date().toISOString().split('T')[0]
    };
    onAddOrder(newOrder);
    setIsModalOpen(false);
    setFormData({ client: '', itemCode: '', qty: 1, price: 0, status: '견적대기' });
  };

  return (
    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-slate-900">견적/수주 관리</h2>
        <button onClick={() => setIsModalOpen(true)} className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 text-sm font-medium shadow-sm">
          <Plus className="w-4 h-4" /> 견적서 작성
        </button>
      </div>
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <table className="w-full text-sm text-left">
          <thead className="bg-slate-50 text-slate-500 border-b border-slate-200">
            <tr><th className="px-6 py-4">일자</th><th className="px-6 py-4">문서번호</th><th className="px-6 py-4">고객사</th><th className="px-6 py-4">품목</th><th className="px-6 py-4">수량</th><th className="px-6 py-4">단가</th><th className="px-6 py-4">총액</th><th className="px-6 py-4">상태</th></tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {orders.map(ord => (
              <tr key={ord.id} className="hover:bg-slate-50">
                <td className="px-6 py-4 text-slate-600">{ord.date}</td>
                <td className="px-6 py-4 font-medium text-indigo-600">{ord.id}</td>
                <td className="px-6 py-4 font-medium text-slate-900">{ord.client}</td>
                <td className="px-6 py-4 text-slate-700">[{ord.itemCode}] {getItemName(ord.itemCode)}</td>
                <td className="px-6 py-4 text-slate-700">{ord.qty}</td>
                <td className="px-6 py-4 text-slate-700">{formatCurrency(ord.price)}</td>
                <td className="px-6 py-4 text-slate-900 font-medium">{formatCurrency(ord.qty * ord.price)}</td>
                <td className="px-6 py-4"><StatusBadge status={ord.status} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {isModalOpen && (
        <Modal title="견적서 작성" onClose={() => setIsModalOpen(false)}>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">고객사 *</label>
              <input type="text" required className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500" value={formData.client} onChange={e => setFormData({...formData, client: e.target.value})} />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">품목 선택 *</label>
              <select required className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500" value={formData.itemCode} onChange={e => setFormData({...formData, itemCode: e.target.value})}>
                <option value="">품목을 선택하세요</option>
                {items.map(item => <option key={item.code} value={item.code}>[{item.code}] {item.name}</option>)}
              </select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">수량 *</label>
                <input type="number" min="1" required className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500" value={formData.qty} onChange={e => setFormData({...formData, qty: parseInt(e.target.value) || 0})} />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">단가 *</label>
                <input type="number" min="0" required className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500" value={formData.price} onChange={e => setFormData({...formData, price: parseInt(e.target.value) || 0})} />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">상태</label>
              <select className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500" value={formData.status} onChange={e => setFormData({...formData, status: e.target.value})}>
                <option value="견적대기">견적대기</option>
                <option value="수주확정">수주확정</option>
              </select>
            </div>
            <button type="submit" className="w-full py-2.5 bg-indigo-600 text-white rounded-lg font-medium hover:bg-indigo-700 mt-6">저장하기</button>
          </form>
        </Modal>
      )}
    </motion.div>
  );
};

const POView = ({ pos, orders, items, onAddPO }: { key?: string, pos: PO[], orders: Order[], items: Item[], onAddPO: (po: PO) => void }) => {
  const [searchCode, setSearchCode] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [formData, setFormData] = useState({ supplier: '', itemCode: '', qty: 1, price: 0, status: '대기중' });
  
  const getItemName = (code: string) => items.find(i => i.code === code)?.name || code;
  
  const filteredPOs = useMemo(() => {
    if (!searchCode) return pos;
    return pos.filter(p => p.itemCode.toLowerCase().includes(searchCode.toLowerCase()));
  }, [searchCode, pos]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.itemCode) return alert('품목을 선택해주세요.');
    const newPO = {
      ...formData,
      id: `PO-${String(pos.length + 1).padStart(3, '0')}`,
      date: new Date().toISOString().split('T')[0]
    };
    onAddPO(newPO);
    setIsModalOpen(false);
    setFormData({ supplier: '', itemCode: '', qty: 1, price: 0, status: '대기중' });
  };

  return (
    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-slate-900">발주 관리 및 상세조회</h2>
        <button onClick={() => setIsModalOpen(true)} className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 text-sm font-medium shadow-sm">
          <Plus className="w-4 h-4" /> 발주서 작성
        </button>
      </div>
      
      <div className="bg-white p-4 rounded-2xl shadow-sm border border-slate-200 flex gap-4 items-center">
        <Search className="w-5 h-5 text-slate-400" />
        <input 
          type="text" 
          placeholder="품목코드로 발주 이력 검색..." 
          className="flex-1 outline-none text-sm"
          value={searchCode}
          onChange={(e) => setSearchCode(e.target.value)}
        />
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <table className="w-full text-sm text-left">
          <thead className="bg-slate-50 text-slate-500 border-b border-slate-200">
            <tr><th className="px-6 py-4">발주일자</th><th className="px-6 py-4">발주번호</th><th className="px-6 py-4">품목</th><th className="px-6 py-4">발주금액</th><th className="px-6 py-4">실적금액(매출)</th><th className="px-6 py-4">상태</th><th className="px-6 py-4">출력</th></tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {filteredPOs.map(po => {
              // 실적 금액: 해당 품목코드의 수주확정된 주문들의 총액
              const performanceAmount = orders
                .filter(o => o.itemCode === po.itemCode && o.status === '수주확정')
                .reduce((sum, o) => sum + (o.qty * o.price), 0);
                
              return (
                <tr key={po.id} className="hover:bg-slate-50">
                  <td className="px-6 py-4 text-slate-600">{po.date}</td>
                  <td className="px-6 py-4 font-medium text-indigo-600">{po.id}</td>
                  <td className="px-6 py-4 text-slate-700">[{po.itemCode}] {getItemName(po.itemCode)}</td>
                  <td className="px-6 py-4 text-slate-700">{formatCurrency(po.qty * po.price)}</td>
                  <td className="px-6 py-4 text-emerald-600 font-medium">{formatCurrency(performanceAmount)}</td>
                  <td className="px-6 py-4"><StatusBadge status={po.status} /></td>
                  <td className="px-6 py-4"><button className="p-2 text-slate-400 hover:text-indigo-600"><Printer className="w-4 h-4" /></button></td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {isModalOpen && (
        <Modal title="발주서 작성" onClose={() => setIsModalOpen(false)}>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">공급사 *</label>
              <input type="text" required className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500" value={formData.supplier} onChange={e => setFormData({...formData, supplier: e.target.value})} />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">품목 선택 *</label>
              <select required className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500" value={formData.itemCode} onChange={e => setFormData({...formData, itemCode: e.target.value})}>
                <option value="">품목을 선택하세요</option>
                {items.map(item => <option key={item.code} value={item.code}>[{item.code}] {item.name}</option>)}
              </select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">수량 *</label>
                <input type="number" min="1" required className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500" value={formData.qty} onChange={e => setFormData({...formData, qty: parseInt(e.target.value) || 0})} />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">발주단가 *</label>
                <input type="number" min="0" required className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500" value={formData.price} onChange={e => setFormData({...formData, price: parseInt(e.target.value) || 0})} />
              </div>
            </div>
            <button type="submit" className="w-full py-2.5 bg-indigo-600 text-white rounded-lg font-medium hover:bg-indigo-700 mt-6">발주하기</button>
          </form>
        </Modal>
      )}
    </motion.div>
  );
};

const ReceivingView = ({ pos, items, onReceivePO }: { key?: string, pos: PO[], items: Item[], onReceivePO: (id: string) => void }) => {
  const [searchPO, setSearchPO] = useState('');
  const getItemName = (code: string) => items.find(i => i.code === code)?.name || code;

  const filteredPOs = searchPO ? pos.filter(p => p.id.toLowerCase().includes(searchPO.toLowerCase())) : pos;

  return (
    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-slate-900">단순 입고 처리</h2>
      </div>
      
      <div className="bg-white p-4 rounded-2xl shadow-sm border border-slate-200 flex gap-4 items-center">
        <Search className="w-5 h-5 text-slate-400" />
        <input 
          type="text" 
          placeholder="발주번호 입력하여 검색..." 
          className="flex-1 outline-none text-sm"
          value={searchPO}
          onChange={(e) => setSearchPO(e.target.value)}
        />
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <table className="w-full text-sm text-left">
          <thead className="bg-slate-50 text-slate-500 border-b border-slate-200">
            <tr><th className="px-6 py-4">발주번호</th><th className="px-6 py-4">품목</th><th className="px-6 py-4">수량</th><th className="px-6 py-4">상태</th><th className="px-6 py-4 text-right">처리</th></tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {filteredPOs.map(po => (
              <tr key={po.id} className="hover:bg-slate-50">
                <td className="px-6 py-4 font-medium text-indigo-600">{po.id}</td>
                <td className="px-6 py-4 text-slate-700">[{po.itemCode}] {getItemName(po.itemCode)}</td>
                <td className="px-6 py-4 text-slate-700">{po.qty}</td>
                <td className="px-6 py-4"><StatusBadge status={po.status} /></td>
                <td className="px-6 py-4 text-right">
                  {po.status === '대기중' && (
                    <button onClick={() => onReceivePO(po.id)} className="px-3 py-1.5 bg-emerald-50 text-emerald-600 rounded-lg text-xs font-medium hover:bg-emerald-100 transition-colors">
                      입고 완료
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </motion.div>
  );
};

const PerformanceView = () => (
  <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
    <div className="flex justify-between items-center">
      <h2 className="text-2xl font-bold text-slate-900">실적 관리</h2>
      <button className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 text-slate-700 rounded-lg hover:bg-slate-50 text-sm font-medium">
        <Download className="w-4 h-4" /> 다운로드
      </button>
    </div>
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
        <h3 className="text-lg font-bold text-slate-900 mb-6">월별 실적</h3>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={mockPerformance.monthlySales}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
              <XAxis dataKey="month" axisLine={false} tickLine={false} />
              <YAxis axisLine={false} tickLine={false} />
              <Tooltip cursor={{ fill: '#f1f5f9' }} />
              <Legend />
              <Bar dataKey="sales" name="매출" fill="#4f46e5" radius={[4, 4, 0, 0]} />
              <Bar dataKey="target" name="목표" fill="#cbd5e1" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  </motion.div>
);

export default function App() {
  const [activeView, setActiveView] = useState<ViewType>('itemMaster');
  
  const [items, setItems] = useState<Item[]>(initialItems);
  const [orders, setOrders] = useState<Order[]>(initialOrders);
  const [pos, setPos] = useState<PO[]>(initialPOs);

  const handleAddItem = (item: Item) => setItems([...items, item]);
  const handleAddOrder = (order: Order) => setOrders([...orders, order]);
  const handleAddPO = (po: PO) => setPos([...pos, po]);
  const handleReceivePO = (id: string) => setPos(pos.map(p => p.id === id ? { ...p, status: '입고완료' } : p));

  const navItems = [
    { id: 'dashboard', label: '대시보드', icon: LayoutDashboard },
    { id: 'itemMaster', label: '품목 마스터', icon: Box },
    { id: 'order', label: '견적/수주 관리', icon: FileText },
    { id: 'po', label: '발주 관리', icon: ShoppingCart },
    { id: 'receiving', label: '입고 처리', icon: ArrowDownRight },
    { id: 'performance', label: '실적 관리', icon: TrendingUp },
  ] as const;

  return (
    <div className="flex h-screen bg-slate-50 font-sans text-slate-900 overflow-hidden">
      <aside className="w-64 bg-slate-900 text-slate-300 flex flex-col flex-shrink-0">
        <div className="h-16 flex items-center px-6 border-b border-slate-800">
          <div className="flex items-center gap-2 text-white font-bold text-xl tracking-tight">
            <div className="w-8 h-8 bg-indigo-500 rounded-lg flex items-center justify-center"><Package className="w-5 h-5 text-white" /></div>
            ERP Demo
          </div>
        </div>
        <nav className="flex-1 py-6 px-4 space-y-1 overflow-y-auto">
          {navItems.map((item) => {
            const isActive = activeView === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveView(item.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 ${isActive ? 'bg-indigo-600 text-white shadow-md shadow-indigo-900/20' : 'hover:bg-slate-800 hover:text-white'}`}
              >
                <item.icon className={`w-5 h-5 ${isActive ? 'text-indigo-200' : 'text-slate-400'}`} />
                <span className="font-medium text-sm">{item.label}</span>
              </button>
            );
          })}
        </nav>
      </aside>
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-8 flex-shrink-0">
          <div className="flex-1" />
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 text-sm font-medium text-slate-700"><User className="w-4 h-4" /> 관리자</div>
          </div>
        </header>
        <div className="flex-1 overflow-y-auto p-8">
          <div className="max-w-6xl mx-auto">
            <AnimatePresence mode="wait">
              {activeView === 'dashboard' && <DashboardView key="dashboard" items={items} orders={orders} pos={pos} />}
              {activeView === 'itemMaster' && <ItemMasterView key="itemMaster" items={items} onAddItem={handleAddItem} />}
              {activeView === 'order' && <OrderView key="order" orders={orders} items={items} onAddOrder={handleAddOrder} />}
              {activeView === 'po' && <POView key="po" pos={pos} orders={orders} items={items} onAddPO={handleAddPO} />}
              {activeView === 'receiving' && <ReceivingView key="receiving" pos={pos} items={items} onReceivePO={handleReceivePO} />}
              {activeView === 'performance' && <PerformanceView key="performance" />}
            </AnimatePresence>
          </div>
        </div>
      </main>
    </div>
  );
}

